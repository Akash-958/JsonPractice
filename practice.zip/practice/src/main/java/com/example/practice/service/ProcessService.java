package com.example.practice.service;

import com.example.practice.beans.RequestData;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.*;

@Service
public class ProcessService {
    @Value("${api.api-1}")
    private String [] api_1;

    public JSONObject processService(RequestData requestData) throws InterruptedException, ExecutionException {
        //
        // System.out.println(api_1[0]);
        ObjectMapper objectMapper = new ObjectMapper();
        JSONObject jsonObject = new JSONObject();
        int json_field_count = api_1.length;
        System.out.println(json_field_count);
        JSONObject json = new JSONObject();
        if(requestData.getApiName().equalsIgnoreCase("API-1")){
            ExecutorService executorService = Executors.newFixedThreadPool(json_field_count);
            Set<Callable<HashMap<String, JsonNode>>> callable = new HashSet<Callable<HashMap<String, JsonNode>>>();
            for(String tag : api_1){
                callable.add(new Callable<HashMap<String,JsonNode>>() {
                    @Override
                    public HashMap<String,JsonNode> call() throws Exception {
                       HashMap map=  new HashMap<String,JsonNode>();
                       map.put(tag, requestData.getRequest().get(tag));
                        System.out.println(map);
                       return map;
                    }
                });


                List<Future<HashMap<String, JsonNode>>> futures = executorService.invokeAll(callable);
                for(Future<HashMap<String, JsonNode>> future: futures){
                    Map<String,JsonNode> map = future.get();

                    for(Map.Entry<String,JsonNode> entry : map.entrySet()){
                        jsonObject.put(entry.getKey(),entry.getValue());
                    }


                }
            }

        }
        System.out.println(jsonObject);
        return jsonObject;
    }
}
