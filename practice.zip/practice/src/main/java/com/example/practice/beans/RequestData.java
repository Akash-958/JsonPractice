package com.example.practice.beans;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

@Data
public class RequestData {

    private String apiName;
    private JsonNode request;

}
