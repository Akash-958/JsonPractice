package com.example.practice.Controller;

import com.example.practice.beans.RequestData;
import com.example.practice.service.ProcessService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/process")
@Slf4j
public class MyController {

    @Autowired
    private ProcessService processService;

    @PostMapping
    public Map<String, Object> process(@RequestBody RequestData requestData) throws ExecutionException, InterruptedException {
        log.debug(requestData.getRequest().asText());

       return processService.processService(requestData).toMap();
        //return  processService.processService(requestData);

    }
}
